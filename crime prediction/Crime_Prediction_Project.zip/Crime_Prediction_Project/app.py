from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

# 1. Load Model
try:
    with open('crime_model.pkl', 'rb') as f:
        data = pickle.load(f)
        model = data["model"]
        encoders = data["encoders"]
except FileNotFoundError:
    print("Error: Run the notebook first to generate the model file!")

@app.route('/')
def home():
    # Pass district options to the HTML dropdown
    options = sorted(encoders['District'].classes_)
    return render_template('index.html', districts=options)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # 1. Get data from form
        district = request.form['District']
        population = float(request.form['Population'])
        unemployment = float(request.form['Unemployment'])
        income = float(request.form['Income'])
        stations = float(request.form['Stations'])
        patrol = float(request.form['Patrol'])

        # 2. Encode District
        district_encoded = encoders['District'].transform([district])[0]

        # 3. Prepare Feature Vector
        # Order: [District, Population, Unemployment_Rate, Median_Income, Police_Stations, Patrol_Hours_Daily]
        features = np.array([[district_encoded, population, unemployment, income, stations, patrol]])

        # 4. Predict
        prediction = model.predict(features)[0]

        # 5. Set Color for UI
        colors = {'High Risk': 'danger', 'Medium Risk': 'warning', 'Low Risk': 'success'}
        color = colors.get(prediction, 'primary')

        return render_template('result.html', prediction=prediction, color=color)

    except Exception as e:
        return f"Error: {e}"

if __name__ == '__main__':
    app.run(debug=True)